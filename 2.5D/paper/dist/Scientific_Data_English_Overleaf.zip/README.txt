Upload this ZIP as a new Overleaf project. main.tex is the main document.
All referenced figures are included in figures/.
This English submission draft compiles with Overleaf's default pdfLaTeX engine.
Replace every bold bracketed repository, DOI, URL, and licence placeholder before submission.
