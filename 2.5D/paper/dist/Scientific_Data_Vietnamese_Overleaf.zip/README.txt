Upload this ZIP as a new Overleaf project. main.tex is the main document.
All referenced figures are included in figures/.
This Vietnamese review copy compiles with Overleaf's default pdfLaTeX engine.
